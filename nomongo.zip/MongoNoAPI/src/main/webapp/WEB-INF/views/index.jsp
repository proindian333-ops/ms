<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>SpringBoot-NoAPI-MongoDB</title>
    <link rel="stylesheet" href="/style.css">
</head>
<body>
<div class="container fade-in">
    <center><h1 class="main-title">SpringBoot-NoAPI-MongoDB</h1></center>
    <div class="card">
        <h2>CREATE Employee</h2>
        <form action="addEmp" method="post">
            <label for="id">ID :</label>
            <input type="text" name="id" id="id" class="input" /><br><br>
            <label for="name">Name :</label>
            <input type="text" name="name" id="name" class="input" /><br><br>
            <input type="submit" class="btn" value="Create" />
        </form>
    </div>
    <div class="card">
        <h2>READ Employee</h2>
        <form action="getEmp" method="get">
            <label for="read-id">ID :</label>
            <input type="text" name="id" id="read-id" class="input" /><br><br>
            <input type="submit" class="btn" value="Read" />
        </form>
    </div>
    <div class="card">
        <h2>UPDATE Employee</h2>
        <form action="updEmp" method="post">
            <label for="update-id">ID :</label>
            <input type="text" name="id" id="update-id" class="input" /><br><br>
            <input type="submit" class="btn" value="Update" />
        </form>
    </div>
    <div class="card">
        <h2>DELETE Employee</h2>
        <form action="delEmp" method="post">
            <label for="delete-id">ID :</label>
            <input type="text" name="id" id="delete-id" class="input" /><br><br>
            <input type="submit" class="btn btn-delete" value="Delete" />
        </form>
    </div>
</div>
</body>
</html>