<html>
<body>
<center><h1>SpringBoot-NoAPI-MongoDB</h1></center>
<h2>CREATE Employee</h2>
<form action="addEmp">
ID : <input type="text" name="id" /><br><br>
Name : <input type="text" name="name" /><br><br>
<input type="submit" />
</form>
<h2>READ Employee</h2>
<form action="getEmp">
ID : <input type="text" name="id" /><br><br>
<input type="submit" />
</form>
<h2>UPDATE Employee</h2>
<form action="updEmp">
ID : <input type="text" name="id" /><br><br>
<input type="submit" />
</form>
<h2>DELETE Employee</h2>
<form action="delEmp">
ID : <input type="text" name="id" /><br><br>

<input type="submit" /> 
</form>
</body>
</html>