package com.example.demo.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import com.example.demo.model.EModel;

public interface ERepo extends MongoRepository<EModel, Integer> { 
    // Inherits save, findById, deleteById, etc.
}