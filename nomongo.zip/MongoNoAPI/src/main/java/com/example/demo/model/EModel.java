package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document("evening") 
public class EModel {
	@Id
	private int id;
	private String name;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public EModel() {
		
	}
	public EModel(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	
    // ...other getters/setters...
}