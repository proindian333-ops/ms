package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.model.EModel;
import com.example.demo.repository.ERepo;

@Controller
public class EController {
    @Autowired
    ERepo erepo;

    @RequestMapping("index")
    public String index() {
        return "index";
    }

    @RequestMapping("addEmp")
    public String addEmp(EModel emodel) {
        erepo.save(emodel);
        return "index";
    }

    @RequestMapping("getEmp")
    public ModelAndView getEmp(@RequestParam int id) {
        ModelAndView mv = new ModelAndView("display");
        EModel emodel = erepo.findById(id).orElse(new EModel());
        mv.addObject("EModel", emodel);
        return mv;
    }

    @RequestMapping("updEmp")
    public ModelAndView updEmp(EModel emodel) {
        ModelAndView mv = new ModelAndView("update");
        EModel found = erepo.findById(emodel.getId()).orElse(new EModel());
        mv.addObject("EModel", found);
        return mv;
    }

    @RequestMapping("delEmp")
    public ModelAndView delEmp(@RequestParam int id) {
        ModelAndView mv = new ModelAndView("delete");
        EModel emodel = erepo.findById(id).orElse(new EModel());
        erepo.deleteById(id);
        mv.addObject("EModel", emodel);
        return mv;
    }
}